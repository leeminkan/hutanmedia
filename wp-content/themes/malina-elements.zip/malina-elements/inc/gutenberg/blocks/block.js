wp.blocks.registerBlockStyle( 'core/separator', {
     name: 'Solid',
     label: 'Solid'
});